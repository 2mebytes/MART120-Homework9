function setup() {
  createCanvas(400, 400);
}

function draw() {
background('#d5e19d');
  strokeWeight(1);
  stroke('#402213');
  fill('#402213');
  triangle(60, 320, 125, 50, 200, 300);
  triangle(200, 300, 275, 50, 340, 320);
  fill('#ffeee0');
  rect(165, 230, 70, 40);
  circle(200, 150, 200);
  triangle(190, 200, 200, 150, 210, 200);
  line(170, 210, 180, 220);
  line(180, 220, 220, 220);
  line(220, 220, 230, 210);
  fill('#fff7eb')
  ellipse(150, 150, 60, 40);
  ellipse(250, 150, 60, 40);
  fill('#5a4a40')
  circle(160, 150, 30);
  circle(260, 150, 30);
  fill('#b6bd71')
  rect(100, 270, 200, 200);
  rect(80, 270, 50, 200);
  rect(270, 270, 50, 200);
  stroke('fff7eb');
  line(165, 270, 165, 340);
  line(235, 270, 235, 340);
  stroke('#402213');
  triangle(100, 270, 165, 270, 200, 300);
  triangle(300, 270, 235, 270, 200, 300);
  fill('#fff7eb');
  triangle(165, 270, 235, 270, 200, 300);
  fill('#402213');
  rect(100, 40, 200, 80);
  rect(75, 50, 40, 250);
  rect(285, 50, 40, 250);
  text('Self Portrait', 10, 360);
  text('By Meaghan Toomey', 10, 375);
  strokeWeight(40);
  stroke('#fdd5c8');
  point(140, 195);
  point(260, 195);
}